﻿let Eb_DBExplorer = function (options) {

    this.TCobj = options.TCobj;

    this.create_tree = function (e) {
        let $e = $(e.target);
        $e.children('div').toggle();
        $e.filter('.parent').toggleClass('expanded');
        return false;
    };

    this.ajax_call = function (e) {
        e.preventDefault();

        var data = editor.getValue();

        $.ajax({
            type: "POST",
            url: "https://localhost:44304/Connect/SqlQuery",
            content: "application/json; charset=utf-8",
            dataType: "json",
            data: { sql:JSON.stringify(data) },
            success: function (d) {
                if (d.success == true)
                    window.location = "index.html";
                else { }
            },
            error: function (xhr, textStatus, errorThrown) {
                // TODO: Show error
            }
        });
    }
    this.onDrop = function (evt, ui) {
        let $source = $(ui.draggable);
        let tableName = $source.parent().attr("table-name");
        if (tableName) {
            let posLeft = event.pageX;
            let posTop = event.pageY;
            let $tableBoxHtml = $(`<div is-draggable="false" class="table-box"><i class="fa fa-window-close-o" aria-hidden="true" onClick="parentNode.remove()"></i></div>`);
            $('.cont').append($tableBoxHtml);
            $tableBoxHtml.css("left", posLeft + "px");
            $tableBoxHtml.css("top", posTop + "px");
            $($tableBoxHtml).append(tableName, "<br />");
            let cname = this.TCobj[tableName].Columns[0]['ColumnName'];
            $.each(this.TCobj[tableName].Columns, function (key, column) {
                $($tableBoxHtml).append(column['ColumnName']);
                $($tableBoxHtml).append(" : ", column['ColumnType'], "<br />");
            })
            if ($tableBoxHtml.attr("is-draggable") == "false") {// if called first time
                $tableBoxHtml.draggable(options);
                $tableBoxHtml.attr("is-draggable", "true");
            }
        }  
    }.bind(this);

    window.onload = function () {
        var mime = 'text/x-mariadb';
        // get mime type
        if (window.location.href.indexOf('mime=') > -1) {
            mime = window.location.href.substr(window.location.href.indexOf('mime=') + 5);
        }
        window.editor = CodeMirror.fromTextArea(document.getElementById('code'), {
            mode: mime,
            indentWithTabs: true,
            smartIndent: true,
            lineNumbers: true,
            matchBrackets: true,
            autofocus: true,
            cursorActive: true,
            extraKeys: { "Ctrl-Space": "autocomplete" },
            hintOptions: {
                tables: {
                    users: ["name", "score", "birthDate"],
                    countries: ["name", "population", "size"]
                }
            }
        });
    };

    this.makeDrop = function () {
        $("#droppable").droppable({ drop: this.onDrop });
    };

    this.makeDraggable = function () {
        let options = new Object();
        options = {
            appendTo: 'body', // Append to the body.
            helper: 'clone',
            containment: $('document'),
            revert: 'invalid'
        };
        $('.table-name').draggable(options);
  
    };

    this.init = function () {
        $('.mytree div:has(div)').addClass('parent');
        $('div.mytree div').click(this.create_tree);
        $('#sqlquery').click(this.ajax_call);
        this.makeDraggable();
        this.makeDrop();
        
    };

    this.init();
}

